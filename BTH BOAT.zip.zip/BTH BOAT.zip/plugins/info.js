let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 BTH ബോട്ട് SA 2.0 〙 ═
╠➥  Made in javascript via NodeJs
╠➥ Rec: Devan [love only]
╠➥ Script: love only
║
╠➥ instagram: https://instagram.com/_king_of_dev._?igshid=1 agygvhp6mkre
╠
║
╠═〘 Thanks To 〙 ═
╠➥ devan 
╠➥ 
║
╠═〘 BTH ബോട്ട് SA  〙 ═
╠➥ MAKE GROUP ADMIN 
╠➥ TURN ON YOUR DATA
╠➥ CONTACT : wa.me//+917025720575
║
║>Request? wa.me//+917025720575
║
╠═〘 BTH 2.0 〙 ═
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

